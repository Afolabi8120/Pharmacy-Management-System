﻿namespace Pharmacy_Software {
    
    
    public partial class DataSet1 
    {

    }
}
